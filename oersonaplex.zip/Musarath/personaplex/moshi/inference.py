# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

"""
SageMaker inference wrapper for PersonaPlex/Moshi.
"""
from __future__ import absolute_import

import os
import tempfile
import base64
import json
from typing import Dict, Any, Tuple, List, Union

import numpy as np
import torch

# DISABLE TORCH COMPILE/INDUCTOR to avoid Triton CUDA errors
# Must be done before importing model code
import torch._dynamo
torch._dynamo.config.suppress_errors = True
# Optionally disable completely:
# torch._dynamo.disable()

import sentencepiece
import sphn
from huggingface_hub import hf_hub_download

# ABSOLUTE IMPORTS (since inference.py is outside the moshi package)
from moshi.client_utils import make_log
from moshi.models import loaders, LMGen, MimiModel
from moshi.models.lm import load_audio as lm_load_audio
from moshi.models.lm import _iterate_audio as lm_iterate_audio
from moshi.models.lm import encode_from_sphn as lm_encode_from_sphn

# Import utility functions from original offline.py
from moshi.offline import (
    log,
    seed_all,
    wrap_with_system_tags,
    warmup,
    decode_tokens_to_pcm,
    _get_voice_prompt_dir,
)


# =============================================================================
# SageMaker Inference Functions
# =============================================================================

def model_fn(model_dir: str, context=None) -> Dict[str, Any]:
    """
    Load model artifacts from HuggingFace for SageMaker inference.

    Downloads models from HF repo (same behavior as original offline.py).
    Requires HF_TOKEN environment variable for authenticated downloads.

    Args:
        model_dir: SageMaker model directory (not used - we download from HF)
        context: SageMaker context (optional)

    Returns:
        Dictionary containing all loaded models and configurations.
    """
    # Disable torch compile to avoid Triton/CUDA issues
    torch._dynamo.config.suppress_errors = True

    device = "cuda" if torch.cuda.is_available() else "cpu"
    hf_repo = loaders.DEFAULT_REPO

    # Check for HF token
    hf_token = os.environ.get("HF_TOKEN")
    if hf_token:
        log("info", "HF_TOKEN found in environment")
    else:
        log("warning", "HF_TOKEN not set - downloads may fail for gated models")

    log("info", f"Loading models from HuggingFace repo: {hf_repo} on device: {device}")

    # Download config.json to increment download counter (same as original)
    hf_hub_download(hf_repo, "config.json")

    # 1) Download and load Mimi encoders/decoders (same as original offline.py)
    log("info", "Downloading and loading Mimi")
    mimi_weight = hf_hub_download(hf_repo, loaders.MIMI_NAME)
    mimi = loaders.get_mimi(mimi_weight, device)
    other_mimi = loaders.get_mimi(mimi_weight, device)
    log("info", "Mimi loaded")

    # 2) Download and load tokenizer
    log("info", "Downloading and loading tokenizer")
    tokenizer_path = hf_hub_download(hf_repo, loaders.TEXT_TOKENIZER_NAME)
    text_tokenizer = sentencepiece.SentencePieceProcessor(tokenizer_path)
    log("info", "Tokenizer loaded")

    # 3) Download and load Moshi LM
    log("info", "Downloading and loading Moshi LM")
    moshi_weight = hf_hub_download(hf_repo, loaders.MOSHI_NAME)
    lm = loaders.get_moshi_lm(moshi_weight, device=device, cpu_offload=False)
    lm.eval()
    log("info", "Moshi LM loaded")

    # 4) Download and extract voice prompts (same as original offline.py)
    log("info", "Downloading voice prompts")
    voice_prompt_dir = _get_voice_prompt_dir(None, hf_repo)
    log("info", f"Voice prompts available at: {voice_prompt_dir}")

    # Store model artifacts
    model_artifacts = {
        "mimi": mimi,
        "other_mimi": other_mimi,
        "lm": lm,
        "text_tokenizer": text_tokenizer,
        "device": device,
        "voice_prompt_dir": voice_prompt_dir,
        "frame_size": int(mimi.sample_rate / mimi.frame_rate),
        "sample_rate": mimi.sample_rate,
        "frame_rate": mimi.frame_rate,
        "hf_repo": hf_repo,
        "warmed_up": False,
    }

    log("info", "All models loaded successfully from HuggingFace")
    return model_artifacts


def input_fn(request_body: Union[str, bytes], content_type: str) -> Dict[str, Any]:
    """
    Deserialize input data for SageMaker inference.

    Args:
        request_body: Raw request (can be str or bytes depending on SageMaker version)
        content_type: Content type of the request

    Returns:
        Parsed request data dictionary
    """
    log("info", f"Received request with content_type={content_type}, body type={type(request_body)}")

    if content_type == "application/json":
        # Handle both str and bytes (SageMaker may pass either)
        if isinstance(request_body, bytes):
            request_data = json.loads(request_body.decode("utf-8"))
        else:
            request_data = json.loads(request_body)

        # Handle base64 encoded audio
        if "input_audio" in request_data and "input_audio_bytes" not in request_data:
            request_data["input_audio_bytes"] = base64.b64decode(request_data["input_audio"])

        return request_data

    elif content_type in ["audio/wav", "audio/x-wav", "audio/wave"]:
        # Raw WAV sent - use defaults
        # Ensure we have bytes
        if isinstance(request_body, str):
            audio_bytes = request_body.encode("latin-1")  # Preserve binary data
        else:
            audio_bytes = request_body

        return {
            "input_audio_bytes": audio_bytes,
            "text_prompt": "You are a wise and friendly teacher. Answer questions or provide advice in a clear and engaging way.",
            "voice_prompt": "NATF2.pt",
        }

    else:
        raise ValueError(f"Unsupported content type: {content_type}")


def predict_fn(input_data: Dict[str, Any], model: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run inference using pre-loaded models.

    Args:
        input_data: Parsed request data from input_fn
        model: Dictionary containing loaded models from model_fn

    Returns:
        Dictionary with inference results
    """
    # Extract parameters with defaults (matching original CLI defaults)
    text_prompt = input_data.get(
        "text_prompt", 
        "You are a wise and friendly teacher. Answer questions or provide advice in a clear and engaging way."
    )
    voice_prompt = input_data.get("voice_prompt", "NATF2.pt")
    temp_audio = input_data.get("temp_audio", 0.8)
    temp_text = input_data.get("temp_text", 0.7)
    topk_audio = input_data.get("topk_audio", 250)
    topk_text = input_data.get("topk_text", 25)
    greedy = input_data.get("greedy", False)
    seed = input_data.get("seed", -1)

    if "input_audio_bytes" not in input_data:
        raise ValueError("No input audio provided. Use 'input_audio' (base64) or send raw WAV")

    input_audio_bytes = input_data["input_audio_bytes"]

    with torch.no_grad():
        result = _run_inference_from_bytes(
            model=model,
            input_audio_bytes=input_audio_bytes,
            text_prompt=text_prompt,
            voice_prompt=voice_prompt,
            temp_audio=temp_audio,
            temp_text=temp_text,
            topk_audio=topk_audio,
            topk_text=topk_text,
            greedy=greedy,
            seed=seed,
        )

    return result


def output_fn(prediction: Dict[str, Any], accept: str) -> Tuple[bytes, str]:
    """
    Serialize prediction output for SageMaker response.

    Args:
        prediction: Inference results from predict_fn
        accept: Desired response content type

    Returns:
        Tuple of (response_body, response_content_type)
    """
    log("info", f"Formatting response with accept={accept}")

    if accept in ["audio/wav", "audio/x-wav", "audio/wave"]:
        return prediction["audio_bytes"], "audio/wav"

    elif accept == "*/*":
        # Default to JSON for wildcard
        response = {
            "text_tokens": prediction["text_tokens"],
            "audio_base64": base64.b64encode(prediction["audio_bytes"]).decode("utf-8"),
            "sample_rate": prediction["sample_rate"],
        }
        return json.dumps(response).encode("utf-8"), "application/json"

    else:
        # JSON response with base64 audio
        response = {
            "text_tokens": prediction["text_tokens"],
            "audio_base64": base64.b64encode(prediction["audio_bytes"]).decode("utf-8"),
            "sample_rate": prediction["sample_rate"],
        }
        return json.dumps(response).encode("utf-8"), "application/json"


# =============================================================================
# Internal Inference Logic (mirrors original offline.py run_inference)
# =============================================================================

def _run_inference_from_bytes(
    model: Dict[str, Any],
    input_audio_bytes: bytes,
    text_prompt: str,
    voice_prompt: str,
    temp_audio: float = 0.8,
    temp_text: float = 0.7,
    topk_audio: int = 250,
    topk_text: int = 25,
    greedy: bool = False,
    seed: int = -1,
) -> Dict[str, Any]:
    """
    Run inference using pre-loaded models and audio bytes.

    This mirrors the logic from original offline.py run_inference function.
    """
    # Seed if requested (same as original)
    if seed is not None and seed != -1:
        seed_all(seed)

    # Extract model components
    mimi = model["mimi"]
    other_mimi = model["other_mimi"]
    lm = model["lm"]
    text_tokenizer = model["text_tokenizer"]
    device = model["device"]
    frame_size = model["frame_size"]
    sample_rate = model["sample_rate"]
    frame_rate = model["frame_rate"]
    voice_prompt_dir = model["voice_prompt_dir"]

    # 4) Construct LMGen like server.py's ServerState does (same as original)
    lm_gen = LMGen(
        lm,
        audio_silence_frame_cnt=int(0.5 * frame_rate),  # spacer after prompts
        sample_rate=sample_rate,
        device=device,
        frame_rate=frame_rate,
        save_voice_prompt_embeddings=False,
        use_sampling=not greedy,
        temp=temp_audio,
        temp_text=temp_text,
        top_k=topk_audio,
        top_k_text=topk_text,
    )

    # Keep models in streaming mode similar to the server
    mimi.streaming_forever(1)
    other_mimi.streaming_forever(1)
    lm_gen.streaming_forever(1)

    # 5) Warmup if not already done
    if not model.get("warmed_up", False):
        log("info", "Warming up the model")
        warmup(mimi, other_mimi, lm_gen, device, frame_size)
        model["warmed_up"] = True

    # 6) Prompt configuration (text + voice) - same as original
    voice_prompt_path = os.path.join(voice_prompt_dir, voice_prompt)
    if not os.path.exists(voice_prompt_path):
        raise FileNotFoundError(
            f"Voice prompt '{voice_prompt}' not found in '{voice_prompt_dir}'"
        )

    if voice_prompt_path.endswith('.pt'):
        lm_gen.load_voice_prompt_embeddings(voice_prompt_path)
    else:
        lm_gen.load_voice_prompt(voice_prompt_path)

    lm_gen.text_prompt_tokens = (
        text_tokenizer.encode(wrap_with_system_tags(text_prompt)) if len(text_prompt) > 0 else None
    )

    # 7) Reset streaming and run initial prompt phases - same as original
    mimi.reset_streaming()
    other_mimi.reset_streaming()
    lm_gen.reset_streaming()
    lm_gen.step_system_prompts(mimi)
    mimi.reset_streaming()

    # 8) Load user audio from bytes
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_input:
        tmp_input.write(input_audio_bytes)
        tmp_input_path = tmp_input.name

    try:
        user_audio = lm_load_audio(tmp_input_path, sample_rate)
    finally:
        os.unlink(tmp_input_path)

    # 9) Encode user audio with Mimi and step the model - same as original
    generated_frames: List[np.ndarray] = []
    generated_text_tokens: List[str] = []
    total_target_samples = user_audio.shape[-1]

    for user_encoded in lm_encode_from_sphn(
        mimi,
        lm_iterate_audio(
            user_audio, sample_interval_size=lm_gen._frame_size, pad=True
        ),
        max_batch=1,
    ):
        steps = user_encoded.shape[-1]
        for c in range(steps):
            step_in = user_encoded[:, :, c : c + 1]
            tokens = lm_gen.step(step_in)
            if tokens is None:
                continue
            pcm = decode_tokens_to_pcm(mimi, other_mimi, lm_gen, tokens)
            generated_frames.append(pcm)
            # Decode text token - same as original
            text_token = tokens[0, 0, 0].item()
            if text_token not in (0, 3):
                _text = text_tokenizer.id_to_piece(text_token)
                _text = _text.replace("▁", " ")
                log("info", f"text token '{_text}'")
                generated_text_tokens.append(_text)
            else:
                text_token_map = ['EPAD', 'BOS', 'EOS', 'PAD']
                log("info", f"text token '{text_token_map[text_token]}'")
                generated_text_tokens.append(text_token_map[text_token])

    if len(generated_frames) == 0:
        log("error", "No audio frames were generated")
        output_pcm = np.zeros(total_target_samples, dtype=np.float32)
    else:
        # 10) Concatenate frames and trim/pad - same as original
        output_pcm = np.concatenate(generated_frames, axis=-1)
        if output_pcm.shape[-1] > total_target_samples:
            output_pcm = output_pcm[:total_target_samples]
        elif output_pcm.shape[-1] < total_target_samples:
            pad_len = total_target_samples - output_pcm.shape[-1]
            output_pcm = np.concatenate(
                [output_pcm, np.zeros(pad_len, dtype=output_pcm.dtype)], axis=-1
            )

    # 11) Convert to WAV bytes
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_output:
        tmp_output_path = tmp_output.name

    try:
        sphn.write_wav(tmp_output_path, output_pcm, sample_rate)
        with open(tmp_output_path, "rb") as f:
            audio_bytes = f.read()
    finally:
        os.unlink(tmp_output_path)

    log("info", f"Generated {len(generated_text_tokens)} text tokens and {len(audio_bytes)} audio bytes")

    return {
        "audio_bytes": audio_bytes,
        "text_tokens": generated_text_tokens,
        "sample_rate": int(sample_rate),
    }