declare module "opus-recorder";
